package com.yixia.camera.demo.ui;

import android.app.Activity;
import android.os.Bundle;

public class LaunchActivity extends Activity {
	// launcher

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
	}

}
