package com.lansosdk.NoFree;

import android.graphics.Bitmap;

public interface onExtractFrameProgressListener {
    void onExtractBitmap(Bitmap bmp, long ptsUS);
}
