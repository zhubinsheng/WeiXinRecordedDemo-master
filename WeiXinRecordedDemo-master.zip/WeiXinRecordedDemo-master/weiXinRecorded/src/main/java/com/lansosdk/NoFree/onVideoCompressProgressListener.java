package com.lansosdk.NoFree;

public interface onVideoCompressProgressListener {
    void onProgress(int percent);
}
