package com.lansosdk.NoFree;

public interface onVideoCompressCompletedListener {
    void onCompleted(String video);
}
