package com.lansosdk.NoFree;



public interface onExtractFrameCompletedListener {
    void onCompleted();
}
