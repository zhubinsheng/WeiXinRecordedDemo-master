![微信小视频](http://img.blog.csdn.net/20150703110355740)

微信从6.0版本开始推出小视频功能，随着4G网络的出现，视频将会是一个趋势，他能表达出文字所不能表现的东西，增加了微信的黏性。
还记得微信小视频这个功能一推出，如同病毒一样席卷朋友圈。

如果你要问，微博的下一个时代是什么，互联网大佬会告诉你，**短视频**


![微信小视频](http://a1.eoeandroid.com/attachment/forum/201507/15/161150dwgrgh8e0hmg2d8b.png)


作为爱美的我们，怎么能把我们的窘态暴露给朋友圈的小伙伴呢，必须正能量！美好的！必须美化！
So，录制小视频后，加各种滤镜，炫酷MV主题，妈妈再也不担心我的猪窝了...

    
 ![高仿微信 小视频](http://a1.eoeandroid.com/attachment/forum/201507/15/160941j9ztbxxgdxqwxbnt.gif) 

PS：gif 图片比较大，如果等不及的童鞋，可以[点击这里查看视频](http://video.weibo.com/show?fid=1034:b50abae7fe8bd291c5fac40d75a1028a)


Download Apk
===

<a href="http://42.81.5.134/file3.data.weipan.cn/1078079/436bbc923e1886bc3c82c16ece8a98ddd8ae7a23?ip=1436780160,124.207.56.162&ssig=62aV9bk2ip&Expires=1436781930&KID=sae,l30zoo1wmz&fn=%E9%AB%98%E4%BB%BF%E5%BE%AE%E4%BF%A1.apk&skiprd=2&se_ip_debug=124.207.56.162&corp=2&from=1221134&wsiphost=local">
  <img alt="Get it on Google Play"
       src="https://developer.android.com/images/brand/en_generic_rgb_wo_60.png" />
</a>
