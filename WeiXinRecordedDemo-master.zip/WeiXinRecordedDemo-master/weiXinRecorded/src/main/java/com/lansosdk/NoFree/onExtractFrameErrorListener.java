package com.lansosdk.NoFree;

public interface onExtractFrameErrorListener {
    void onError();
}
