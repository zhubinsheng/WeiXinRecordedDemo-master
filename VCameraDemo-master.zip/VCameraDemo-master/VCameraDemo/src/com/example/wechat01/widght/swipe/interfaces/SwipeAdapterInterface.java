package com.example.wechat01.widght.swipe.interfaces;

public interface SwipeAdapterInterface {
	public int getSwipeLayoutResourceId(int position);
}
